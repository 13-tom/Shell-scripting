# Shell Scripting Basics 🐚

This repository covers the basics of shell scripting with a simple example to get started.

---

## 📌 What is Shell Scripting?

Shell scripting is the process of writing a plain text file containing a sequence of commands that the shell executes one by one. It’s a powerful way to automate repetitive or complex tasks efficiently.

---

## 🔑 Key Features

- Automates repetitive tasks.
- Runs multiple commands with a single script.
- Serves as documentation for your workflow.
- Supports logic with **if-else statements**, **loops**, and **variables**.

---

## 🚀 Your First Shell Script

### Step 1: Create the Script

Create a file called `first.sh` and add:

```bash
echo "Hello World"
echo "This is our first shell script."
pwd
date
```

### Step 2: Make it Executable

```bash
chmod +x first.sh
```

### Step 3: Run the Script

```bash
./first.sh
```

### ✅ Expected Output

```
Hello World
This is our first shell script.
/home/kali/shellscript-youtube
Wed May 4 06:36:07 AM EDT 2022
```

---

## 🧠 Explaining the Commands

| Command       | Description                          |
|---------------|--------------------------------------|
| `echo`        | Prints text to the terminal          |
| `pwd`         | Shows the current directory          |
| `date`        | Prints current date and time         |
| `chmod +x`    | Grants execute permission            |
| `./first.sh`  | Runs the script                      |

---

## 💡 Tips

- Use `#` to add comments and explanations.
- Test small parts of code before scripting the whole thing.
- Use meaningful names for your scripts.

---

## 📂 Files

- `first.sh`: A simple "Hello World" shell script.
- `scripts/basic-info.sh`: Will contain more basic examples later.
