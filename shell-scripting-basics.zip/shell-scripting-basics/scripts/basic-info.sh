#!/bin/bash
# This script can be expanded for more examples later.
